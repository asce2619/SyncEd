/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package synced;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author janni
 */
public class TeacherInterfaceController implements Initializable {

    @FXML
    private AnchorPane teacherPage;
    @FXML
    private TextArea teacherDayPlan;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void logoutButton(ActionEvent event) throws Exception {
        Stage stageLogin = (Stage) teacherPage.getScene().getWindow();
        stageLogin.close();//close teacher page
            
        /* open login page again */
        javafx.scene.Parent root = FXMLLoader.load(getClass().getResource("FrontPageInterface.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }
    
    /**
     * 
     * @param event 
     * 
     * Saving the teachers plan in a text file
     */
    @FXML
    private void savePlan(ActionEvent event) throws IOException {
        String plan = teacherDayPlan.getText();
        
        File fileName = new File("DayPlan" + ".txt");
        if(fileName.createNewFile() == true){
            FileWriter writeToFile = new FileWriter("DayPlan" + ".txt");
            writeToFile.write(plan);
            writeToFile.close();
        }
        else{
            FileWriter writer = new FileWriter("DayPlan" + ".txt");
            writer.append(plan);
            writer.flush();
        }
    }

    /**
     * 
     * @param event 
     * 
     * Uploads previous Day Plan
     */
    @FXML
    private void dayPlanTab(Event event) throws IOException {
        String plan = "";
        
        List<String> allLines = Files.readAllLines(Paths.get("DayPlan.txt"));
        for (String line : allLines) {
            plan += line;
            plan += "\n";
        }
        
        teacherDayPlan.setText(plan);        
    }
}
