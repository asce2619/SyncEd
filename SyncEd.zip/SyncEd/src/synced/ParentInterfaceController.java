/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package synced;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author janni
 */
public class ParentInterfaceController implements Initializable {

    @FXML
    private AnchorPane parentPage;
    @FXML
    private TextArea parentDayPlan;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public ParentAccount p;
    //recives data from login interface after parent login
    public void reciveData(ParentAccount p){
        this.p = p;
    }

    @FXML
    private void logoutButton(ActionEvent event) throws Exception {
        Stage stageLogin = (Stage) parentPage.getScene().getWindow();
        stageLogin.close();//close parent page
            
        /* open login page again */
        javafx.scene.Parent root = FXMLLoader.load(getClass().getResource("FrontPageInterface.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    /**
     * 
     * @param event
     * @throws IOException 
     * 
     * Uploads the Teachers day plan to the parents side
     */
    @FXML
    private void dayPlanTab(Event event) throws IOException {
        String plan = "";
        
        List<String> allLines = Files.readAllLines(Paths.get("DayPlan.txt"));
        for (String line : allLines) {
            plan += line;
            plan += "\n";
        }
        
        parentDayPlan.setText(plan);
    }
    
}
